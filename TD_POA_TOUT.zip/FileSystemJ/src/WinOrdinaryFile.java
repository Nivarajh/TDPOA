/**
 * Created by nijeyaku on 25/10/2016.
 */
public class WinOrdinaryFile {
}
