/**
 * Created by nijeyaku on 25/10/2016.
 */
public interface Creator {

    public Product createProduct();
    public abstract Product createCreator();

}




