/**
 * Created by nijeyaku on 25/10/2016.
 */
public class ConcrateProductFr implements Product {

   public void getName()
   {
       System.out.println("Je suis un produit fran�ais.");
   }
}
