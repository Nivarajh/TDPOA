/**
 * Created by nijeyaku on 25/10/2016.
 */
public class ConcrateProductEn implements Product {

    public void getName()
    {
        System.out.println("Je suis un produit anglais.");
    }
}
