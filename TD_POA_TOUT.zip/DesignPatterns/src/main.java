/**
 * Created by nijeyaku on 25/10/2016.
 */
public class main {



    public static void main(String[] args)
    {
        Client c = new Client();
        Product p = c.getProduct();
        System.out.println(p);

        Client c1 = new Client();
        Product p1 = c1.getProduct();
        System.out.println(p1);

        Client c2 = new Client();
        Product p2 = c2.getProduct();
        System.out.println(p2);





    }



}
