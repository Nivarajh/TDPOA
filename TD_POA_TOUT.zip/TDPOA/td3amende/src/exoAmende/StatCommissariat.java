package exoAmende;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("b5545afb-2593-11e2-9612-0800270b393c")
public class StatCommissariat {
    @objid ("b5545af8-2593-11e2-9612-0800270b393c")
    private int cptCatA = 0;

    @objid ("b5545af3-2593-11e2-9612-0800270b393c")
    private int cptCatB = 0;

    @objid ("b5545afe-2593-11e2-9612-0800270b393c")
    private int cptCatC = 0;


    @objid ("2d3af3b5-2595-11e2-9612-0800270b393c")
    public StatCommissariat() {
    }

    @objid ("fc6605c5-2596-11e2-9612-0800270b393c")
    public int getCptCatA() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.cptCatA;
    }

    @objid ("fd112ac5-2596-11e2-9612-0800270b393c")
    public void setCptCatA(final int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.cptCatA = value;
    }

    @objid ("00751d45-2597-11e2-9612-0800270b393c")
    public int getCptCatB() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.cptCatB;
    }

    @objid ("012f8a25-2597-11e2-9612-0800270b393c")
    public void setCptCatB(final int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.cptCatB = value;
    }

    @objid ("037bd955-2597-11e2-9612-0800270b393c")
    public int getCptCatC() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.cptCatC;
    }

    @objid ("03f79f85-2597-11e2-9612-0800270b393c")
    public void setCptCatC(final int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.cptCatC = value;
    }

}
