package src.fr.p10.miage.rps.model;

import test.tests.RockPaperScissorsTest;

/**
 * Created by nijeyaku on 27/09/2016.
 */
public class Main {


    public static void main(String[] args) {
        RockPaperScissorsTest rps = new RockPaperScissorsTest();

    }

}
