package src.fr.p10.miage.rps.model;

/**
 * Created by nijeyaku on 27/09/2016.
 */
public enum Result {
    WIN,
    LOST,
    TIE


}
